
/**
 * @author Gurpreet Singh
 *
 */
public abstract class AbstractFactory {

	/**
	 * 
	 */
	public AbstractFactory() {
		// TODO Auto-generated constructor stub
	}

}
